// Main JavaScript for Brillant Zid Theme
document.addEventListener('DOMContentLoaded', function() {
    // Initialize sliders
    initSliders();
    
    // Initialize product gallery
    initProductGallery();
    
    // Initialize quantity inputs
    initQuantityInputs();
    
    // Initialize tabs
    initTabs();
    
    // Initialize dropdowns
    initDropdowns();
    
    // Initialize mobile menu
    initMobileMenu();
    
    // Initialize chat widget
    initChatWidget();
    
    // Initialize notification center
    initNotificationCenter();
    
    // Initialize product 360 view
    initProduct360View();
    
    // Initialize survey options
    initSurveyOptions();
    
    // Initialize subscription options
    initSubscriptionOptions();
    
    // Initialize payment options
    initPaymentOptions();
    
    // Initialize shipping options
    initShippingOptions();
    
    // Initialize coupon code copy
    initCouponCopy();
    
    // Initialize language switcher
    initLanguageSwitcher();
});

// Initialize sliders
function initSliders() {
    // Check if Swiper is available
    if (typeof Swiper !== 'undefined') {
        // Main slider
        new Swiper('.main-swiper', {
            loop: true,
            autoplay: {
                delay: 5000,
                disableOnInteraction: false,
            },
            pagination: {
                el: '.swiper-pagination',
                clickable: true,
            },
            navigation: {
                nextEl: '.swiper-button-next',
                prevEl: '.swiper-button-prev',
            },
        });
        
        // Announcement slider
        new Swiper('.announcement-slider', {
            loop: true,
            autoplay: {
                delay: 3000,
                disableOnInteraction: false,
            },
            direction: 'vertical',
        });
    }
}

// Initialize product gallery
function initProductGallery() {
    const mainImg = document.querySelector('.product-main-img');
    const thumbnails = document.querySelectorAll('.product-thumbnail');
    
    if (mainImg && thumbnails.length > 0) {
        thumbnails.forEach(thumbnail => {
            thumbnail.addEventListener('click', function() {
                // Remove active class from all thumbnails
                thumbnails.forEach(t => t.classList.remove('active'));
                
                // Add active class to clicked thumbnail
                this.classList.add('active');
                
                // Update main image
                const imageUrl = this.getAttribute('data-image');
                mainImg.style.backgroundImage = `url('${imageUrl}')`;
            });
        });
    }
}

// Initialize quantity inputs
function initQuantityInputs() {
    const quantityInputs = document.querySelectorAll('.quantity-input');
    
    quantityInputs.forEach(input => {
        const minusBtn = input.querySelector('.minus');
        const plusBtn = input.querySelector('.plus');
        const inputField = input.querySelector('input');
        
        if (minusBtn && plusBtn && inputField) {
            minusBtn.addEventListener('click', function() {
                let value = parseInt(inputField.value);
                if (value > parseInt(inputField.getAttribute('min') || 1)) {
                    inputField.value = value - 1;
                    // Trigger change event
                    const event = new Event('change');
                    inputField.dispatchEvent(event);
                }
            });
            
            plusBtn.addEventListener('click', function() {
                let value = parseInt(inputField.value);
                const max = parseInt(inputField.getAttribute('max') || 9999);
                if (value < max) {
                    inputField.value = value + 1;
                    // Trigger change event
                    const event = new Event('change');
                    inputField.dispatchEvent(event);
                }
            });
        }
    });
}

// Initialize tabs
function initTabs() {
    const tabs = document.querySelectorAll('.product-tab');
    const tabContents = document.querySelectorAll('.tab-content');
    
    if (tabs.length > 0 && tabContents.length > 0) {
        tabs.forEach(tab => {
            tab.addEventListener('click', function() {
                // Remove active class from all tabs
                tabs.forEach(t => t.classList.remove('active'));
                
                // Add active class to clicked tab
                this.classList.add('active');
                
                // Hide all tab contents
                tabContents.forEach(content => content.classList.remove('active'));
                
                // Show corresponding tab content
                const tabId = this.getAttribute('data-tab');
                document.getElementById(tabId).classList.add('active');
            });
        });
    }
}

// Initialize dropdowns
function initDropdowns() {
    const dropdownTriggers = document.querySelectorAll('.nav-categories > li > a');
    
    dropdownTriggers.forEach(trigger => {
        // Check if this trigger has a dropdown
        const dropdown = trigger.nextElementSibling;
        if (dropdown && dropdown.classList.contains('nav-dropdown')) {
            // For mobile, add click event
            trigger.addEventListener('click', function(e) {
                // Only for mobile view
                if (window.innerWidth <= 768) {
                    e.preventDefault();
                    dropdown.style.display = dropdown.style.display === 'block' ? 'none' : 'block';
                }
            });
        }
    });
    
    // Language switcher dropdown
    const langSwitcher = document.querySelector('.lang-switcher');
    if (langSwitcher) {
        langSwitcher.addEventListener('click', function() {
            const dropdown = this.querySelector('.lang-dropdown');
            if (dropdown) {
                dropdown.style.display = dropdown.style.display === 'block' ? 'none' : 'block';
            }
        });
        
        // Close dropdown when clicking outside
        document.addEventListener('click', function(e) {
            if (!langSwitcher.contains(e.target)) {
                const dropdown = langSwitcher.querySelector('.lang-dropdown');
                if (dropdown) {
                    dropdown.style.display = 'none';
                }
            }
        });
    }
}

// Initialize mobile menu
function initMobileMenu() {
    const menuToggle = document.querySelector('.menu-toggle');
    const navMain = document.querySelector('.nav-main');
    
    if (menuToggle && navMain) {
        menuToggle.addEventListener('click', function() {
            navMain.classList.toggle('active');
        });
    }
}

// Initialize chat widget
function initChatWidget() {
    const chatButton = document.querySelector('.chat-button');
    const chatWindow = document.querySelector('.chat-window');
    const chatClose = document.querySelector('.chat-close');
    const chatInput = document.querySelector('.chat-input input');
    const chatSend = document.querySelector('.chat-input button');
    const chatMessages = document.querySelector('.chat-messages');
    
    if (chatButton && chatWindow && chatClose) {
        chatButton.addEventListener('click', function() {
            chatWindow.style.display = 'block';
        });
        
        chatClose.addEventListener('click', function() {
            chatWindow.style.display = 'none';
        });
        
        if (chatInput && chatSend && chatMessages) {
            chatSend.addEventListener('click', function() {
                const message = chatInput.value.trim();
                if (message) {
                    // Add user message
                    const userMessage = document.createElement('div');
                    userMessage.className = 'chat-message user';
                    userMessage.textContent = message;
                    chatMessages.appendChild(userMessage);
                    
                    // Clear input
                    chatInput.value = '';
                    
                    // Scroll to bottom
                    chatMessages.scrollTop = chatMessages.scrollHeight;
                    
                    // Simulate response after 1 second
                    setTimeout(function() {
                        const supportMessage = document.createElement('div');
                        supportMessage.className = 'chat-message support';
                        supportMessage.textContent = 'شكراً لتواصلك معنا. سيتم الرد عليك في أقرب وقت ممكن.';
                        chatMessages.appendChild(supportMessage);
                        
                        // Scroll to bottom
                        chatMessages.scrollTop = chatMessages.scrollHeight;
                    }, 1000);
                }
            });
            
            // Send message on Enter key
            chatInput.addEventListener('keypress', function(e) {
                if (e.key === 'Enter') {
                    chatSend.click();
                }
            });
        }
    }
}

// Initialize notification center
function initNotificationCenter() {
    const notificationButton = document.querySelector('.notification-button');
    const notificationCenter = document.querySelector('.notification-center');
    const notificationClose = document.querySelector('.notification-close');
    
    if (notificationButton && notificationCenter && notificationClose) {
        notificationButton.addEventListener('click', function() {
            notificationCenter.classList.add('active');
        });
        
        notificationClose.addEventListener('click', function() {
            notificationCenter.classList.remove('active');
        });
        
        // Close when clicking outside
        document.addEventListener('click', function(e) {
            if (notificationCenter && !notificationCenter.contains(e.target) && e.target !== notificationButton) {
                notificationCenter.classList.remove('active');
            }
        });
    }
}

// Initialize product 360 view
function initProduct360View() {
    const view360Icon = document.querySelector('.view-360-icon');
    
    if (view360Icon) {
        view360Icon.addEventListener('click', function() {
            const productId = this.getAttribute('data-product-id');
            const mainImg = document.querySelector('.product-main-img');
            
            if (mainImg) {
                // Toggle 360 view mode
                if (mainImg.classList.contains('view-360-active')) {
                    mainImg.classList.remove('view-360-active');
                    this.querySelector('i').classList.remove('fa-pause');
                    this.querySelector('i').classList.add('fa-sync-alt');
                } else {
                    mainImg.classList.add('view-360-active');
                    this.querySelector('i').classList.remove('fa-sync-alt');
                    this.querySelector('i').classList.add('fa-pause');
                    
                    // Here you would load the 360 view images and initialize the 360 viewer
                    // This is a simplified example
                    console.log('Loading 360 view for product ID:', productId);
                }
            }
        });
    }
}

// Initialize survey options
function initSurveyOptions() {
    const surveyOptions = document.querySelectorAll('.survey-option');
    
    surveyOptions.forEach(option => {
        option.addEventListener('click', function() {
            // Remove selected class from all options
            surveyOptions.forEach(o => o.classList.remove('selected'));
            
            // Add selected class to clicked option
            this.classList.add('selected');
        });
    });
    
    const surveySubmit = document.querySelector('.survey-submit');
    if (surveySubmit) {
        surveySubmit.addEventListener('click', function() {
            const selectedOption = document.querySelector('.survey-option.selected');
            if (selectedOption) {
                // Here you would submit the survey response
                alert('شكراً لمشاركتك في الاستطلاع!');
                
                // Reset survey
                surveyOptions.forEach(o => o.classList.remove('selected'));
            } else {
                alert('الرجاء اختيار إجابة قبل الإرسال.');
            }
        });
    }
}

// Initialize subscription options
function initSubscriptionOptions() {
    const subscriptionOptions = document.querySelectorAll('.subscription-option');
    
    subscriptionOptions.forEach(option => {
        option.addEventListener('click', function() {
            // Remove active class from all options
            subscriptionOptions.forEach(o => o.classList.remove('active'));
            
            // Add active class to clicked option
            this.classList.add('active');
        });
    });
}

// Initialize payment options
function initPaymentOptions() {
    const paymentOptions = document.querySelectorAll('.payment-option');
    
    paymentOptions.forEach(option => {
        option.addEventListener('click', function() {
            // Remove selected class from all options
            paymentOptions.forEach(o => o.classList.remove('selected'));
            
            // Add selected class to clicked option
            this.classList.add('selected');
            
            // Show/hide payment details based on selected option
            const paymentDetails = document.querySelector('.payment-details');
            if (paymentDetails) {
                if (this.querySelector('.payment-option-title').textContent.includes('Visa') || 
                    this.querySelector('.payment-option-title').textContent.includes('Mastercard') || 
                    this.querySelector('.payment-option-title').textContent.includes('Mada')) {
                    paymentDetails.style.display = 'block';
                } else {
                    paymentDetails.style.display = 'none';
                }
            }
        });
    });
}

// Initialize shipping options
function initShippingOptions() {
    const shippingOptions = document.querySelectorAll('.shipping-option');
    
    shippingOptions.forEach(option => {
        option.addEventListener('click', function() {
            // Remove active class from all options
            shippingOptions.forEach(o => o.classList.remove('active'));
            
            // Add active class to clicked option
            this.classList.add('active');
        });
    });
}

// Initialize coupon code copy
function initCouponCopy() {
    const copyButtons = document.querySelectorAll('.copy-code');
    
    copyButtons.forEach(button => {
        button.addEventListener('click', function() {
            const codeValue = this.previousElementSibling.textContent;
            
            // Create temporary input element
            const tempInput = document.createElement('input');
            tempInput.value = codeValue;
            document.body.appendChild(tempInput);
            
            // Select and copy the text
            tempInput.select();
            document.execCommand('copy');
            
            // Remove the temporary input
            document.body.removeChild(tempInput);
            
            // Update button text temporarily
            const originalText = this.textContent;
            this.textContent = 'تم النسخ!';
            
            // Reset button text after 2 seconds
            setTimeout(() => {
                this.textContent = originalText;
            }, 2000);
        });
    });
}

// Initialize language switcher
function initLanguageSwitcher() {
    const langLinks = document.querySelectorAll('.lang-option');
    
    langLinks.forEach(link => {
        link.addEventListener('click', function(e) {
            e.preventDefault();
            
            const lang = this.getAttribute('data-lang');
            if (lang === 'ar') {
                document.documentElement.setAttribute('dir', 'rtl');
                document.body.classList.remove('en');
            } else {
                document.documentElement.setAttribute('dir', 'ltr');
                document.body.classList.add('en');
            }
            
            // Here you would redirect to the language URL
            // window.location.href = this.getAttribute('href');
        });
    });
}

// Add to cart functionality
function addToCart(productId, quantity = 1) {
    console.log(`Adding product ${productId} to cart with quantity ${quantity}`);
    
    // Here you would make an AJAX request to add the product to the cart
    // This is a simplified example
    
    // Show success message
    showNotification('تمت إضافة المنتج إلى سلة التسوق بنجاح!', 'success');
    
    // Update cart count
    updateCartCount();
}

// Update cart count
function updateCartCount() {
    const cartCount = document.querySelector('.header-icon .count');
    if (cartCount) {
        let count = parseInt(cartCount.textContent);
        cartCount.textContent = count + 1;
    }
}

// Show notification
function showNotification(message, type = 'info') {
    // Create notification element
    const notification = document.createElement('div');
    notification.className = `notification notification-${type}`;
    notification.innerHTML = `
        <div class="notification-content">
            <i class="fas fa-${type === 'success' ? 'check-circle' : type === 'error' ? 'exclamation-circle' : 'info-circle'}"></i>
            <span>${message}</span>
        </div>
        <button class="notification-close"><i class="fas fa-times"></i></button>
    `;
    
    // Add to document
    document.body.appendChild(notification);
    
    // Add show class after a small delay (for animation)
    setTimeout(() => {
        notification.classList.add('show');
    }, 10);
    
    // Add close event
    const closeBtn = notification.querySelector('.notification-close');
    if (closeBtn) {
        closeBtn.addEventListener('click', function() {
            notification.classList.remove('show');
            setTimeout(() => {
                document.body.removeChild(notification);
            }, 300);
        });
    }
    
    // Auto close after 5 seconds
    setTimeout(() => {
        if (document.body.contains(notification)) {
            notification.classList.remove('show');
            setTimeout(() => {
                if (document.body.contains(notification)) {
                    document.body.removeChild(notification);
                }
            }, 300);
        }
    }, 5000);
}

// Add event listeners for add to cart buttons
document.addEventListener('click', function(e) {
    if (e.target.classList.contains('add-to-cart') || e.target.closest('.add-to-cart')) {
        const button = e.target.classList.contains('add-to-cart') ? e.target : e.target.closest('.add-to-cart');
        const productId = button.getAttribute('data-product-id');
        
        // Find quantity input if it exists
        let quantity = 1;
        const quantityInput = document.querySelector('.quantity-input input');
        if (quantityInput) {
            quantity = parseInt(quantityInput.value);
        }
        
        addToCart(productId, quantity);
    }
    
    if (e.target.classList.contains('add-to-cart-detail') || e.target.closest('.add-to-cart-detail')) {
        const button = e.target.classList.contains('add-to-cart-detail') ? e.target : e.target.closest('.add-to-cart-detail');
        const productId = button.getAttribute('data-product-id');
        
        // Find quantity input
        let quantity = 1;
        const quantityInput = document.querySelector('.quantity-input input');
        if (quantityInput) {
            quantity = parseInt(quantityInput.value);
        }
        
        addToCart(productId, quantity);
    }
});

// Add event listeners for wishlist buttons
document.addEventListener('click', function(e) {
    if (e.target.classList.contains('add-to-wishlist') || e.target.closest('.add-to-wishlist')) {
        const button = e.target.classList.contains('add-to-wishlist') ? e.target : e.target.closest('.add-to-wishlist');
        const productId = button.getAttribute('data-product-id');
        
        // Toggle wishlist icon
        const icon = button.querySelector('i');
        if (icon) {
            if (icon.classList.contains('far')) {
                icon.classList.remove('far');
                icon.classList.add('fas');
                showNotification('تمت إضافة المنتج إلى المفضلة!', 'success');
            } else {
                icon.classList.remove('fas');
                icon.classList.add('far');
                showNotification('تمت إزالة المنتج من المفضلة!', 'info');
            }
        }
    }
});

// Add event listeners for compare buttons
document.addEventListener('click', function(e) {
    if (e.target.classList.contains('compare-btn') || e.target.closest('.compare-btn')) {
        const button = e.target.classList.contains('compare-btn') ? e.target : e.target.closest('.compare-btn');
        const productId = button.getAttribute('data-product-id');
        
        showNotification('تمت إضافة المنتج إلى المقارنة!', 'success');
    }
});

// Add event listeners for variant options
document.addEventListener('click', function(e) {
    if (e.target.classList.contains('variant-option') || e.target.closest('.variant-option')) {
        const option = e.target.classList.contains('variant-option') ? e.target : e.target.closest('.variant-option');
        const variantGroup = option.closest('.variant-group');
        
        if (variantGroup) {
            const options = variantGroup.querySelectorAll('.variant-option');
            options.forEach(o => o.classList.remove('active'));
            option.classList.add('active');
        }
    }
});

// Add event listeners for color options
document.addEventListener('click', function(e) {
    if (e.target.classList.contains('color-option')) {
        const colorOptions = document.querySelectorAll('.color-option');
        colorOptions.forEach(o => o.classList.remove('selected'));
        e.target.classList.add('selected');
    }
});

// Add event listeners for address actions
document.addEventListener('click', function(e) {
    if (e.target.classList.contains('add-address-btn')) {
        // Here you would show address form
        alert('سيتم فتح نموذج إضافة عنوان جديد');
    }
    
    if (e.target.classList.contains('edit-address')) {
        const addressId = e.target.getAttribute('data-address-id');
        // Here you would show address form with existing data
        alert(`سيتم فتح نموذج تعديل العنوان رقم ${addressId}`);
    }
    
    if (e.target.classList.contains('set-default-address')) {
        const addressId = e.target.getAttribute('data-address-id');
        // Here you would set address as default
        alert(`سيتم تعيين العنوان رقم ${addressId} كعنوان افتراضي`);
    }
    
    if (e.target.classList.contains('delete-address')) {
        const addressId = e.target.getAttribute('data-address-id');
        // Here you would delete address
        if (confirm('هل أنت متأكد من حذف هذا العنوان؟')) {
            alert(`سيتم حذف العنوان رقم ${addressId}`);
        }
    }
});

// Add event listeners for rating select
document.addEventListener('click', function(e) {
    if (e.target.classList.contains('fa-star') && e.target.closest('.rating-select')) {
        const stars = e.target.closest('.rating-select').querySelectorAll('.fa-star');
        const rating = parseInt(e.target.getAttribute('data-rating'));
        
        stars.forEach((star, index) => {
            if (index < rating) {
                star.classList.remove('far');
                star.classList.add('fas');
            } else {
                star.classList.remove('fas');
                star.classList.add('far');
            }
        });
    }
});

// Add event listeners for social share buttons
document.addEventListener('click', function(e) {
    if (e.target.closest('.share-button')) {
        const button = e.target.closest('.share-button');
        const url = encodeURIComponent(window.location.href);
        const title = encodeURIComponent(document.title);
        
        if (button.classList.contains('share-facebook')) {
            window.open(`https://www.facebook.com/sharer/sharer.php?u=${url}`, '_blank');
        } else if (button.classList.contains('share-twitter')) {
            window.open(`https://twitter.com/intent/tweet?url=${url}&text=${title}`, '_blank');
        } else if (button.classList.contains('share-whatsapp')) {
            window.open(`https://api.whatsapp.com/send?text=${title} ${url}`, '_blank');
        } else if (button.classList.contains('share-telegram')) {
            window.open(`https://t.me/share/url?url=${url}&text=${title}`, '_blank');
        }
    }
});

// Add event listeners for promo code application
document.addEventListener('click', function(e) {
    if (e.target.closest('.promo-input button')) {
        const input = e.target.closest('.promo-input').querySelector('input');
        const code = input.value.trim();
        
        if (code) {
            // Here you would apply the promo code
            alert(`سيتم تطبيق الرمز الترويجي: ${code}`);
            input.value = '';
        } else {
            alert('الرجاء إدخال رمز ترويجي صحيح');
        }
    }
});

// Add event listeners for place order button
document.addEventListener('click', function(e) {
    if (e.target.classList.contains('place-order-btn')) {
        // Here you would submit the order
        alert('سيتم إرسال الطلب');
    }
});

// Add event listeners for profile form submission
document.addEventListener('submit', function(e) {
    if (e.target.classList.contains('profile-form')) {
        e.preventDefault();
        // Here you would submit the profile form
        alert('سيتم حفظ التغييرات');
    }
});

// Add event listeners for review form submission
document.addEventListener('submit', function(e) {
    if (e.target.closest('.review-form')) {
        e.preventDefault();
        // Here you would submit the review form
        alert('شكراً لتقييمك!');
    }
});

// Add event listeners for window resize
window.addEventListener('resize', function() {
    // Reset mobile menu
    const navMain = document.querySelector('.nav-main');
    if (navMain && window.innerWidth > 768) {
        navMain.classList.remove('active');
    }
});

// Add event listeners for window load
window.addEventListener('load', function() {
    // Show page after everything is loaded
    document.body.classList.add('loaded');
});
